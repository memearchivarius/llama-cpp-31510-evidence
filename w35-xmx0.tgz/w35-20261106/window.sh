#!/usr/bin/env bash
set -Eeuo pipefail
W=/root/apc-probe/llamacpp/w35-20261106
IMAGE=sha256:0e359e5e1cc7170afe773998308b770cd6b613232960e1e9a43df07c6ae0303f
NAME=llama31510-w35
PROD=b60-local-vllm
mkdir -p "$W"
exec > >(tee -a "$W/window.log") 2>&1
date -Is
git -C /opt/llama.cpp rev-parse HEAD
docker inspect "$PROD" --format '{{.Image}} {{.State.Status}}'
test "$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:18083/health)" = 200
if ss -nt state established '( sport = :18083 or sport = :18084 )' | tail -n +2 | grep -q .; then
  echo 'active client socket; refusing window'; exit 1
fi
if curl -fsS http://127.0.0.1:18083/metrics | grep -E 'vllm:num_requests_(running|waiting)\{' | grep -vE ' 0\.0$'; then
  echo 'active or waiting request; refusing window'; exit 1
fi
cleanup() {
  set +e
  echo "cleanup $(date -Is)"
  docker rm -f "$NAME" >/dev/null 2>&1
  systemctl reset-failed "$PROD" >/dev/null 2>&1
  systemctl start "$PROD"
  for i in $(seq 1 90); do
    sleep 10
    if [ "$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:18083/health)" = 200 ]; then
      echo "prod_health=200 after $((i*10)) sec"
      break
    fi
  done
  curl -s -o /dev/null -w 'prod_final_health=%{http_code}\n' http://127.0.0.1:18083/health
  docker inspect "$PROD" --format 'prod_image={{.Image}} status={{.State.Status}}'
  systemctl stop llama31510-w35-rollback.timer >/dev/null 2>&1
  date -Is
}
systemctl stop "$PROD"
trap cleanup EXIT
systemd-run --unit=llama31510-w35-rollback --on-active=65min /bin/sh -c 'docker rm -f llama31510-w35 >/dev/null 2>&1; systemctl reset-failed b60-local-vllm; systemctl start b60-local-vllm' >/dev/null
cat /opt/llm-gguf/glm53-flash/*.gguf >/dev/null
for ARM in dual40xmx0; do
  echo "arm=$ARM start=$(date -Is)"
  if [ "$ARM" = single ]; then
    DEVICES=(--device /dev/dri/renderD128)
    SELECTOR=level_zero:0
  else
    DEVICES=(--device /dev/dri/renderD128 --device /dev/dri/renderD129)
    SELECTOR=level_zero:0,1
  fi
  docker run -d --rm --name "$NAME" --cap-add SYS_PTRACE --security-opt seccomp=unconfined \
    "${DEVICES[@]}" --memory 32g \
    -e ONEAPI_DEVICE_SELECTOR="$SELECTOR" -e GGML_SYCL_XMX_GATHER_TYPES=0 \
    -v /opt/llama.cpp:/src:ro -v /opt/llm-gguf:/models:ro -v "$W":/artifacts \
    --entrypoint sleep "$IMAGE" infinity >/dev/null
  cat > "$W/server-$ARM.sh" <<'EOS'
#!/usr/bin/env bash
source /opt/intel/oneapi/setvars.sh --force >/dev/null 2>&1 || true
export LD_LIBRARY_PATH=/src/build-sycl-prod/bin:$LD_LIBRARY_PATH
exec /src/build-sycl-prod/bin/llama-server \
  -m /models/glm53-flash/GLM-5.3-Flash-UD-IQ2_XXS-00001-of-00004.gguf \
  -ngl 999 -sm layer -cmoe --moe-cache-mib 40000 -fa on -c 16384 -b 2048 -ub 2048 -t 32 \
  -lv 4 --host 127.0.0.1 --port 18085
EOS
  chmod +x "$W/server-$ARM.sh"
  docker exec -d "$NAME" bash -c "bash /artifacts/server-$ARM.sh > /artifacts/server-$ARM.log 2>&1"
  READY=0
  for i in $(seq 1 120); do
    sleep 10
    if [ "$(docker exec "$NAME" curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:18085/health 2>/dev/null)" = 200 ]; then
      READY=1; echo "arm=$ARM ready_after=$((i*10))sec"; break
    fi
    if ! docker exec "$NAME" pgrep -f '^/src/build-sycl-prod/bin/llama-server' >/dev/null; then
      echo "arm=$ARM server_died"; tail -40 "$W/server-$ARM.log"; exit 1
    fi
  done
  if [ "$READY" != 1 ]; then echo "arm=$ARM startup_timeout"; exit 1; fi
  cat > "$W/request.json" <<'EOS'
{"messages":[{"role":"user","content":"hi"}],"max_tokens":4,"temperature":0,"ignore_eos":true,"cache_prompt":false}
EOS
  echo "arm=$ARM probe_start=$(date -Is)"
  docker exec "$NAME" curl -sS --max-time 420 -w '\nHTTP=%{http_code} total=%{time_total} first_byte=%{time_starttransfer}\n' \
    http://127.0.0.1:18085/v1/chat/completions \
    -H 'Content-Type: application/json' --data-binary @/artifacts/request.json \
    > "$W/response-$ARM.txt" 2> "$W/curl-$ARM.err" || true
  echo "arm=$ARM probe_end=$(date -Is)"
  tail -c 500 "$W/response-$ARM.txt"; echo
  grep -E 'prompt processing|generation eval|moe_cache|MoE cache size' "$W/server-$ARM.log" | tail -25 || true
  docker exec "$NAME" bash -c "kill -TERM \$(pgrep -f '^/src/build-sycl-prod/bin/llama-server' | head -1)" || true
  sleep 5
  docker rm -f "$NAME" >/dev/null 2>&1 || true
done
echo WINDOW_DONE
