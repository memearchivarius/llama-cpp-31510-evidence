#!/usr/bin/env bash
source /opt/intel/oneapi/setvars.sh --force >/dev/null 2>&1 || true
export LD_LIBRARY_PATH=/src/build-sycl-prod/bin:$LD_LIBRARY_PATH
exec /src/build-sycl-prod/bin/llama-server \
  -m /models/glm53-flash/GLM-5.3-Flash-UD-IQ2_XXS-00001-of-00004.gguf \
  -ngl 999 -sm layer -cmoe --moe-cache-mib 40000 -fa on -c 16384 -b 2048 -ub 2048 -t 32 \
  -lv 4 --host 127.0.0.1 --port 18085
